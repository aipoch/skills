---
name: abstract-summarizer
description: Summarize long academic papers into structured abstracts within 250 words. Trigger when user provides a paper (PDF, text, or URL) and requests a summary, abstract, or TL;DR. Optimized for research papers, theses, and technical reports.
---

# Abstract Summarizer

A specialized skill for condensing lengthy academic papers into concise, structured abstracts while preserving scientific accuracy.

## Purpose

Transform complex academic documents (research papers, theses, technical reports) into standardized 250-word structured abstracts that capture:
- Research background and motivation
- Methodology and approach
- Key findings and results
- Conclusions and implications

## Trigger Conditions

Activate this skill when:
1. User provides a paper (PDF, text, URL) and asks for summary/abstract
2. User explicitly requests "TL;DR" or "executive summary"
3. User needs to quickly understand a paper's core contribution
4. Processing academic or technical documents >1000 words

## Input Format

Accepted inputs:
- PDF file path or content
- Plain text of paper content
- URL to paper (will fetch content)
- Clipboard text containing paper

## Output Format

Structured abstract with exactly these sections:

```
**Background**: [1 sentence on context and problem]

**Objective**: [1 sentence on research goal]

**Methods**: [1-2 sentences on methodology]

**Results**: [2-3 sentences on key findings]

**Conclusion**: [1 sentence on implications]

---
Word count: XXX/250
```

## Technical Approach

### Extraction Strategy
1. **Identify structure**: Parse paper sections (Abstract, Intro, Methods, Results, Discussion)
2. **Key sentence extraction**: Use positional and semantic cues to identify critical sentences
3. **Core concept identification**: Extract research questions, hypotheses, main findings
4. **Redundancy elimination**: Remove citations, methodological details, minor results

### Condensation Rules
- Preserve technical terminology and quantitative results
- Maintain logical flow between sections
- Ensure standalone comprehensibility
- Strict 250-word limit with counter validation

## Difficulty Level

**High** - Requires understanding of:
- Academic writing conventions across disciplines
- Scientific methodology terminology
- Context-dependent information prioritization
- Cross-domain knowledge integration

## Quality Criteria

A successful abstract must:
- [ ] Accurately represent the paper's core contribution
- [ ] Be understandable without reading the original
- [ ] Include specific quantitative results where present
- [ ] Maintain scientific rigor and precision
- [ ] Stay within 250-word limit
- [ ] Follow the structured format consistently

## Limitations

- May miss nuanced arguments in humanities papers
- Complex mathematical proofs may be oversimplified
- Domain-specific jargon requires contextual understanding
- Multi-study papers need selective focus

## Example Usage

```python
# Direct usage
python scripts/main.py --input paper.pdf --output summary.txt

# From text
python scripts/main.py --text "[paste paper content]" --format structured
```

## References

See `references/` for:
- `abstract-templates.md`: Discipline-specific abstract templates
- `evaluation-rubric.md`: Quality assessment criteria
- `example-abstracts/`: Sample inputs and outputs for testing

---

**Author**: AI Assistant  
**Version**: 1.0  
**Last Updated**: 2026-02-05  
**Status**: Ready for use (requires human review for complex papers)
